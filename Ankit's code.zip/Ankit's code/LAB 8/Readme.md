## This is the only lab, I haven't coded properly ##

# [1] The reason being, for android devices I am not fimiliar with sqllite and against using it #
# [2] I recommend people to use REST_API by making their own backend from Django or Firebase or NodeJS #
# [3] But i present to you the sample code of SQLlite, use this to solve the question of other Apps #
